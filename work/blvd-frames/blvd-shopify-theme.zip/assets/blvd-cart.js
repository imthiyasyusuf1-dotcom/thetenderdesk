/**
 * blvd-cart.js
 * AJAX cart drawer on Shopify's Cart API (/cart.js, /cart/add.js, /cart/change.js).
 * Product forms keep working without JS (they post to /cart/add); this upgrades them.
 */
const drawer = document.querySelector('[data-cart-drawer]');
const list = drawer.querySelector('[data-cart-items]');
const subtotal = drawer.querySelector('[data-cart-subtotal]');
const counts = document.querySelectorAll('[data-cart-count]');
const fmt = (cents) => new Intl.NumberFormat(document.documentElement.lang || 'en-US', { style: 'currency', currency: window.Shopify?.currency?.active || 'USD' }).format(cents / 100);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const root = window.Shopify?.routes?.root || '/';

async function api(path, body) {
  const r = await fetch(root + path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) } : { headers: { Accept: 'application/json' } });
  const j = await r.json();
  if (!r.ok) throw new Error(j.description || j.message || 'Cart error');
  return j;
}

function render(cart) {
  counts.forEach((c) => (c.textContent = cart.item_count));
  subtotal.textContent = fmt(cart.total_price);
  drawer.querySelector('[data-cart-checkout]').toggleAttribute('disabled', !cart.item_count);
  list.innerHTML = cart.item_count ? cart.items.map((it) => `
    <div class="ci" data-key="${it.key}">
      <img src="${it.image ? it.image + (it.image.includes('?') ? '&' : '?') + 'width=200' : ''}" alt="${esc(it.product_title)}" width="78" height="98" loading="lazy">
      <div><h4>${esc(it.product_title)}</h4>${it.variant_title ? `<small>${esc(it.variant_title)}</small>` : ''}
        <div class="qty"><button type="button" data-q="-1" aria-label="Decrease quantity">−</button><span>${it.quantity}</span><button type="button" data-q="1" aria-label="Increase quantity">+</button></div></div>
      <span>${fmt(it.final_line_price)}</span>
    </div>`).join('') : `<p class="drawer-empty">${esc(drawer.dataset.empty)}</p>`;
}

export const refresh = () => api('cart.js').then(render);
export function open() { drawer.classList.add('open'); window.BLVD_LENIS?.stop(); drawer.querySelector('.drawer-panel').focus(); }
export function close() { drawer.classList.remove('open'); window.BLVD_LENIS?.start(); }
export async function add(id, quantity = 1) {
  await api('cart/add.js', { items: [{ id, quantity }] });
  await refresh(); open();
}

list.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-q]'); if (!b) return;
  const row = b.closest('[data-key]'); const q = +row.querySelector('.qty span').textContent + +b.dataset.q;
  row.style.opacity = .5;
  render(await api('cart/change.js', { id: row.dataset.key, quantity: Math.max(0, q) }));
});
drawer.addEventListener('click', (e) => { if (e.target.closest('[data-cart-close]')) close(); });
addEventListener('keydown', (e) => { if (e.key === 'Escape' && drawer.classList.contains('open')) close(); });
document.querySelectorAll('[data-cart-open]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); refresh(); open(); }));

// Progressive enhancement for every product form on the page.
document.addEventListener('submit', async (e) => {
  const f = e.target.closest('form[action$="/cart/add"]'); if (!f) return;
  e.preventDefault();
  const btn = f.querySelector('[type=submit]'); btn.setAttribute('aria-busy', 'true');
  try { await add(+new FormData(f).get('id'), +(new FormData(f).get('quantity') || 1)); }
  catch (err) { const m = f.querySelector('[data-form-error]'); if (m) m.textContent = err.message; }
  btn.removeAttribute('aria-busy');
});

window.BLVD = Object.assign(window.BLVD || {}, { addToCart: add });
